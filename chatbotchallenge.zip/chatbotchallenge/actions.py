# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/core/actions/#custom-actions/


# This is a simple example for a custom action which utters "Hello World!"

from typing import Any, Text, Dict, List

from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
import requests


class ActionStateCoronaCount(Action):
    
    def name(self) -> Text:
        return "action_corona_state"

    def run(self, dispatchSer: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        response = requests.get("https://api.covid19india.org/data.json").json()        
        entities = tracker.latest_message['entities']
        state = None
       
        print("Last message now",entities)
        message  ="Please enter proper messsage"  
        for e in entities:
            if e['entity'] == "state":
                state = e['value']
                
               
        
        if state == "india":
            state = "Total"
             
        for d in response["statewise"]:
            if d["state"] == state.title():
                #state = d['value']       
                message =  "Active : "+ d["active"] + "  Confirmed : "+ d["confirmed"] +  " recovered: " + d["recovered"]
                
        dispatchSer.utter_message(text=message)

        return []

#ActionStateCoronaCount()
# class ActionStateCoronaCount(Action):
#     def name(self) -> Text:
#         return "action_state_risk"

#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
#         response = request.get("https://api.covid19india.org/data.json").json()
        
#         entities = tracker.latest_message('entities')
        
#         print("Last message now",entities)
        
#         for e in entities:
#             if e['entity'] = "state":
#                 state = e['value']

#         dispatcher.utter_message(text="Hello State!" +state)

#         return []