## bot challenge
* bot_challenge
  - utter_iamabot

## what is corona
* corona_intro
  - utter_corona_intro

## how does corona spread
* corona_spread
  - utter_corona_spread
## corona food spread
* corona_food_spread
  - utter_corona_food_spread

## corona warm weather
* warm_weather
  - utter_warm_weather
## corona high risk
* high_risk
   - utter_high_risk

## corna pincode
* pincode_risk
  - utter_pincode_risk


# corona tracker
* corna_state
     - action_corona_state