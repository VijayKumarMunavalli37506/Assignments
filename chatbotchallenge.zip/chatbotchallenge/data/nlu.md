## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:goodbye
- bye
- goodbye
- see you around
- see you later

## intent:bot_challenge
- are you a bot?
- are you a human?
- am I talking to a bot?
- am I talking to a human?

## intent:corona_intro
- What is corona virus
- what is covid
- what is a novel corona virus
- what is covid-19
- tell me about corona
- can you tell me about covid
- corona

## intent:corona_spread
- how does corona virus spread
- how does the virus spread

## intent:corona_food_spread
- Does corona spread from food
- how will corona spread from food

## intent:warm_weather
- will warm weather stop the spread
- will it stop with warm weather

## intent:high_risk
- who is at a higher risk of infection

## intent:pincode_risk
- what is pincode for highly infected
- Pincode

## intent:corna_state
-[india](state)
-[karnataka](state)
-[Goa](state)
-[Punjab](state)
-[Gujarat](state)
-[delhi](state)
-[Andhra Pradesh](state)
-[bihar](state)
-[punjab](state)
-[west bangal](state)
-[odhisha](state)
-[assam](state)
